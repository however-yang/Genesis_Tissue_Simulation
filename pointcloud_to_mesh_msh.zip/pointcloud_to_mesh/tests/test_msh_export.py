import subprocess
from collections import Counter
from itertools import combinations
import sys
import tempfile
import unittest
from pathlib import Path

import meshio
import numpy as np
import open3d as o3d


SCRIPT = Path(__file__).resolve().parents[1] / "pointcloud_to_mesh.py"


class MeshExportTests(unittest.TestCase):
    def run_cli(self, source, destination, *options):
        result = subprocess.run(
            [sys.executable, str(SCRIPT), "--input", str(source), "--output", str(destination), *options],
            capture_output=True, text=True, timeout=120,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def make_surface(self):
        points = np.array([
            [-12.3456789012345, 0.25, 7.125],
            [-10.125, 0.25, 7.125],
            [-12.3456789012345, 3.75, 7.125],
            [-12.3456789012345, 0.25, 11.5],
        ])
        faces = np.array([[0, 2, 1], [0, 1, 3], [0, 3, 2], [1, 2, 3]], dtype=np.int32)
        surface = o3d.geometry.TriangleMesh(
            o3d.utility.Vector3dVector(points), o3d.utility.Vector3iVector(faces)
        )
        return surface, points, faces

    def test_existing_mesh_msh_preserves_geometry_and_tags(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            surface, points, faces = self.make_surface()
            source, destination = root / "surface.ply", root / "nested/surface.msh"
            self.assertTrue(o3d.io.write_triangle_mesh(str(source), surface))
            self.run_cli(source, destination, "--msh-type", "surface")
            text = destination.read_text(encoding="utf-8")
            self.assertTrue(text.startswith("$MeshFormat\n2.2 0 8\n"))
            exported = meshio.read(destination)
            np.testing.assert_allclose(exported.points, points, rtol=0, atol=1e-12)
            np.testing.assert_array_equal(exported.cells_dict["triangle"], faces)
            self.assertEqual(set(exported.cells_dict), {"triangle"})
            np.testing.assert_array_equal(exported.field_data["surface"], [1, 2])
            for tag in ("gmsh:physical", "gmsh:geometrical"):
                np.testing.assert_array_equal(exported.cell_data_dict[tag]["triangle"], np.ones(4))

    def test_pointcloud_poisson_and_bpa_export_msh(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            sphere = o3d.geometry.TriangleMesh.create_sphere(resolution=20)
            sphere.compute_vertex_normals()
            o3d.utility.random.seed(7)
            cloud = sphere.sample_points_uniformly(500)
            source = root / "points.ply"
            self.assertTrue(o3d.io.write_point_cloud(str(source), cloud))
            for method in ("poisson", "bpa"):
                with self.subTest(method=method):
                    destination = root / f"{method}.msh"
                    self.run_cli(source, destination, "--method", method, "--depth", "5", "--msh-type", "surface")
                    exported = meshio.read(destination)
                    self.assertEqual(set(exported.cells_dict), {"triangle"})
                    self.assertGreater(len(exported.cells_dict["triangle"]), 0)
                    self.assertTrue(np.isfinite(exported.points).all())
                    self.assertGreaterEqual(exported.cells_dict["triangle"].min(), 0)
                    self.assertLess(exported.cells_dict["triangle"].max(), len(exported.points))

    def check_volume(self, exported):
        self.assertEqual(set(exported.cells_dict), {"triangle", "tetra"})
        elements = exported.cells_dict["tetra"]
        self.assertGreater(len(elements), 0)
        corners = exported.points[elements]
        volumes = np.einsum(
            "ij,ij->i", np.cross(corners[:, 1] - corners[:, 0], corners[:, 2] - corners[:, 0]),
            corners[:, 3] - corners[:, 0],
        ) / 6
        self.assertTrue(np.isfinite(volumes).all())
        self.assertTrue((volumes > 0).all())
        all_faces = Counter(tuple(sorted(face)) for element in elements for face in combinations(element, 3))
        boundary = {face for face, count in all_faces.items() if count == 1}
        triangles = exported.cells_dict["triangle"]
        self.assertEqual({tuple(sorted(face)) for face in triangles}, boundary)
        self.assertEqual(len(triangles), len(boundary))
        np.testing.assert_array_equal(exported.field_data["surface"], [1, 2])
        np.testing.assert_array_equal(exported.field_data["volume"], [2, 3])
        return volumes

    def test_volume_mesh_covers_the_solid_and_respects_size(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            surface, points, _ = self.make_surface()
            source, destination = root / "solid.ply", root / "solid.msh"
            self.assertTrue(o3d.io.write_triangle_mesh(str(source), surface))
            self.run_cli(source, destination, "--tet-max-volume", "0.25")
            volumes = self.check_volume(meshio.read(destination))
            expected = abs(np.linalg.det((points[1:] - points[0]).T)) / 6
            self.assertAlmostEqual(volumes.sum(), expected, places=9)
            self.assertLessEqual(volumes.max(), 0.25 * (1 + 1e-8))

    def test_pointcloud_to_volume_msh(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            sphere = o3d.geometry.TriangleMesh.create_sphere(resolution=20)
            sphere.compute_vertex_normals()
            o3d.utility.random.seed(7)
            cloud = sphere.sample_points_uniformly(500)
            source, destination = root / "points.ply", root / "solid.msh"
            self.assertTrue(o3d.io.write_point_cloud(str(source), cloud))
            self.run_cli(source, destination, "--method", "poisson", "--depth", "5")
            self.check_volume(meshio.read(destination))

    def test_open_surface_is_rejected_for_volume_export(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            surface, _, faces = self.make_surface()
            surface.triangles = o3d.utility.Vector3iVector(faces[:-1])
            source, destination = root / "open.ply", root / "invalid.msh"
            self.assertTrue(o3d.io.write_triangle_mesh(str(source), surface))
            result = subprocess.run(
                [sys.executable, str(SCRIPT), "--input", str(source), "--output", str(destination)],
                capture_output=True, text=True, timeout=120,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("closed, manifold surface", result.stderr)
            self.assertFalse(destination.exists())

    def test_existing_ply_output_still_works(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            surface, points, faces = self.make_surface()
            source, destination = root / "surface.ply", root / "copy.ply"
            self.assertTrue(o3d.io.write_triangle_mesh(str(source), surface))
            self.run_cli(source, destination, "--input-type", "mesh")
            exported = o3d.io.read_triangle_mesh(str(destination))
            np.testing.assert_allclose(np.asarray(exported.vertices), points, rtol=0, atol=1e-12)
            np.testing.assert_array_equal(np.asarray(exported.triangles), faces)


if __name__ == "__main__":
    unittest.main()
